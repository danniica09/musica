function searchMusic() {
  const input = $("#search-input").val().toLowerCase();
  $("#music-list").html("");

  const musicDB = [
    {
      titulo: "Tusa",
      artista: "Karol G ft. Nicki Minaj",
      genero: "Reguetón",
      duracion: "3:20",
      edad: "Todas las edades",
      imagen: "https://i.imgur.com/eqd2rKP.jpg",
      audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3"
    },
    {
      titulo: "Blinding Lights",
      artista: "The Weeknd",
      genero: "Pop",
      duracion: "3:22",
      edad: "13+",
      imagen: "https://i.imgur.com/qyZVEG2.jpg",
      audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3"
    },
    {
      titulo: "Bohemian Rhapsody",
      artista: "Queen",
      genero: "Rock",
      duracion: "5:55",
      edad: "Todas las edades",
      imagen: "https://i.imgur.com/ksyHL3p.jpg",
      audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3"
    },
    {
      titulo: "Levitating",
      artista: "Dua Lipa",
      genero: "Pop",
      duracion: "3:24",
      edad: "Todas las edades",
      imagen: "https://i.imgur.com/dqfbzRL.jpg",
      audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3"
    },
    {
      titulo: "As It Was",
      artista: "Harry Styles",
      genero: "Indie Pop",
      duracion: "2:47",
      edad: "Todas las edades",
      imagen: "https://i.imgur.com/n7CqqSI.jpg",
      audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-5.mp3"
    },
    {
      titulo: "Me Porto Bonito",
      artista: "Bad Bunny ft. Chencho Corleone",
      genero: "Reguetón",
      duracion: "2:58",
      edad: "18+",
      imagen: "https://i.imgur.com/EfW7Y1j.jpg",
      audio: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-6.mp3"
    }
  ];

  const results = musicDB.filter(song =>
    song.titulo.toLowerCase().includes(input) ||
    song.artista.toLowerCase().includes(input) ||
    song.genero.toLowerCase().includes(input)
  );

  if (results.length === 0) {
    $("#music-list").html("<p class='text-center col-12'>No se encontraron resultados.</p>");
  } else {
    $.each(results, function (i, song) {
      $("#music-list").append(`
        <div class="col-md-4 mb-4">
          <div class="card h-100">
            <img src="${song.imagen}" class="card-img-top" alt="${song.titulo}">
            <div class="card-body">
              <h5 class="card-title">${song.titulo}</h5>
              <p class="card-text">
                <strong>Artista:</strong> ${song.artista}<br>
                <strong>Género:</strong> ${song.genero}<br>
                <strong>Duración:</strong> ${song.duracion}<br>
                <strong>Clasificación:</strong> ${song.edad}
              </p>
              <button class="btn btn-outline-primary btn-sm add-favorite">⭐ Agregar a favoritos</button>
              <a href="${song.audio}" target="_blank" class="btn btn-outline-success btn-sm ml-2">🎧 Escuchar</a>
            </div>
          </div>
        </div>
      `);
    });
  }
}

// Evento click del botón Buscar
$("#search-button").on("click", function () {
  searchMusic();
});

// Evento presionar Enter en input
$("#search-input").on("keyup", function (e) {
  if (e.keyCode === 13) {
    searchMusic();
  }
});

// Mostrar favoritos
$("#ver-favoritos").on("click", function () {
  const favoritos = JSON.parse(localStorage.getItem("favoritos")) || [];
  $("#music-list").html("");

  if (favoritos.length === 0) {
    $("#music-list").html("<p class='text-center col-12'>No hay canciones favoritas.</p>");
    return;
  }

  $.each(favoritos, function (i, song) {
    $("#music-list").append(`
      <div class="col-md-4 mb-4">
        <div class="card h-100">
          <img src="${song.imagen}" class="card-img-top" alt="${song.titulo}">
          <div class="card-body">
            <h5 class="card-title">${song.titulo}</h5>
            <p class="card-text">
              <strong>Artista:</strong> ${song.artista}<br>
              <strong>Género:</strong> ${song.genero}<br>
              <strong>Duración:</strong> ${song.duracion}<br>
              <strong>Clasificación:</strong> ${song.edad}
            </p>
            <a href="${song.audio}" target="_blank" class="btn btn-outline-success btn-sm">🎧 Escuchar</a>
          </div>
        </div>
      </div>
    `);
  });
});

// Guardar favorito al dar clic
$(document).on("click", ".add-favorite", function () {
  const card = $(this).closest(".card");
  const song = {
    titulo: card.find(".card-title").text(),
    artista: card.find(".card-text").html().match(/Artista:<\/strong> (.*?)<br>/)[1],
    genero: card.find(".card-text").html().match(/Género:<\/strong> (.*?)<br>/)[1],
    duracion: card.find(".card-text").html().match(/Duración:<\/strong> (.*?)<br>/)[1],
    edad: card.find(".card-text").html().match(/Clasificación:<\/strong> (.*?)<\/p>/)[1],
    imagen: card.find("img").attr("src"),
    audio: card.find("a").attr("href")
  };

  let favoritos = JSON.parse(localStorage.getItem("favoritos")) || [];
  favoritos.push(song);
  localStorage.setItem("favoritos", JSON.stringify(favoritos));
  alert(`🎉 Agregaste "${song.titulo}" a tus favoritos`);
});
